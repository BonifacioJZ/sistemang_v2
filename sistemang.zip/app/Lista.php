<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use APP\User;

class Lista extends Model
{
    protected $fillable = [
        'name'
    ];
}
