<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Confirmación</div>
                <div class="card-body">
                    <h4 class="card-title">Esta informacion se eliminara para siempre ¿Desea Continuar?</h4>
                    <div class="btn-group">
                        <a href="<?php echo e(route('cita.index')); ?>" class="btn btn-success">No</a>
                        <form method="POST" action="<?php echo e(route('cita.destroy',$cita->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger">Si</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistemang\resources\views/citas/confirm.blade.php ENDPATH**/ ?>