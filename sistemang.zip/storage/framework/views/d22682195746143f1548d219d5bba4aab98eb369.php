<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="card text-center">
            <div class="card-header">
                Cita para la Fecha <?php echo e($cita->fecha); ?> a las <?php echo e($cita->hora_de_inicio); ?> hasta <?php echo e($cita->hora_de_finalizacion); ?>


            </div>
            <div class="card-body">
              <h5 class="card-title"><?php echo e($cita->title); ?></h5>
              <p class="card-text"><?php echo e($cita->descripcion); ?></p>
              Creada por: <span class="card-text" ><?php echo e($cita->user->name); ?> <?php echo e($cita->user->last_name); ?></span>
              <br>
              <?php if($cita->status): ?>
              <div class="alert alert-primary " role="alert">
                Activa
              </div>
              <?php else: ?>
              <div class="alert alert-danger" role="alert">
                Cancelada
              </div>
              <?php endif; ?><br>
              <div class="btn-group btn-group " >
                <a href="<?php echo e(route('cita.edit',$cita->id)); ?>" class="btn btn-warning">Editar</a>
                <a href="#" class="btn btn-danger">Eliminar</a>
            </div>
            </div>
          </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistemang\resources\views/citas/citasshow.blade.php ENDPATH**/ ?>