<?php $__env->startSection('content'); ?>

<div class="container" >
    <div class="row-cols-md-6">
        <div>
            <div class="btn-group" >
                <a href="<?php echo e(route('cita.create')); ?>" class="btn btn-success">Crear Cita</a>
            </div>
        </div>
    </div>
    <br>

    <div class="justify-content-center">
      <table class="table">
        <thead>
            <tr>
              <th scope="col" >Titulo</th>
              <th scope="col" > Descripcion</th>
              <th scope="col" > Fecha </th>
              <th scope="col"> Hora</th>
              <th scope="col"> Acciones </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cita->status): ?>
                <tbody>
                    <th scope="row" ><?php echo e($cita->title); ?></th>
                    <th><?php echo e($cita->descripcion); ?></th>
                    <th><?php echo e($cita->fecha); ?></th>
                    <th><?php echo e($cita->hora_de_inicio); ?></th>
                    <th>
                        <div class="btn-group" >
                            <a href="<?php echo e(route('cita.show',$cita->id)); ?>" class="btn btn-primary btn-sm">Ver Cita</a>
                            <a href="<?php echo e(route('cita.confirm',$cita->id)); ?>" class="btn btn-danger btn-sm">Eliminar</a>
                        </div>
                    </th>
                </tbody>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </table>

    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistemang\resources\views/citas/citasindex.blade.php ENDPATH**/ ?>